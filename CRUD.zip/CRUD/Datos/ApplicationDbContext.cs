using Microsoft.EntityFrameworkCore;
using CRUD.Models; 

namespace CRUD.Datos 
{
    public class ApplicationDbContext : DbContext
    {
        // El constructor es necesario para la inyección de dependencias
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }
        public DbSet<Contacto> Contacto { get; set; }
    }
}