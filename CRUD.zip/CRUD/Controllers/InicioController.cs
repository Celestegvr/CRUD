using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CRUD.Datos;  
using CRUD.Models;
using System.Threading.Tasks;

namespace CRUD.Controllers 
{
    public class InicioController : Controller
    {
        private readonly ApplicationDbContext _contexto;

        public InicioController(ApplicationDbContext contexto)
        {
            _contexto = contexto;
        }

        // 1. LEER: Mostrar la lista de contactos (HTTP GET)
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            return View(await _contexto.Contacto.ToListAsync());
        }

        // 2. CREAR: Mostrar el formulario vacío (HTTP GET)
        [HttpGet]
        public IActionResult Crear()
        {
            return View();
        }

        // 3. CREAR: Guardar los datos en la base de datos (HTTP POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Crear(Contacto contacto)
        {
            if (ModelState.IsValid)
            {
                _contexto.Contacto.Add(contacto);
                await _contexto.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(contacto);
        }

        // 4. ACTUALIZAR: Mostrar el formulario lleno con los datos (HTTP GET)
        [HttpGet]
        public IActionResult Editar(int? id)
        {
            if (id == null) return NotFound();

            var contacto = _contexto.Contacto.Find(id);
            if (contacto == null) return NotFound();

            return View(contacto);
        }

        // 5. ACTUALIZAR: Guardar los cambios editados (HTTP POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Editar(Contacto contacto)
        {
            if (ModelState.IsValid)
            {
                _contexto.Contacto.Update(contacto);
                await _contexto.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(contacto);
        }

        // 6. LEER (Detalle): Mostrar información de un solo usuario (HTTP GET)
        [HttpGet]
        public IActionResult Detalle(int? id)
        {
            if (id == null) return NotFound();

            var contacto = _contexto.Contacto.Find(id);
            if (contacto == null) return NotFound();

            return View(contacto);
        }

        // 7. BORRAR: Mostrar pantalla de confirmación (HTTP GET)
        [HttpGet]
        public IActionResult Borrar(int? id)
        {
            if (id == null) return NotFound();

            var contacto = _contexto.Contacto.Find(id);
            if (contacto == null) return NotFound();

            return View(contacto);
        }

        // 8. BORRAR: Eliminar físicamente el registro (HTTP POST)
        [HttpPost, ActionName("Borrar")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> BorrarContacto(int? id)
        {
            var contacto = await _contexto.Contacto.FindAsync(id);
            if (contacto == null) return View();

            _contexto.Contacto.Remove(contacto);
            await _contexto.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}